var searchData=
[
  ['admin_0',['admin',['../class_menu.html#a213388213efb9265f06f06fdf657c729',1,'Menu']]]
];
