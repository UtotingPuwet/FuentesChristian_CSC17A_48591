var searchData=
[
  ['usemenu_0',['useMenu',['../class_menu.html#ad80dbd65ba30756d548cebf555416f17',1,'Menu']]]
];
