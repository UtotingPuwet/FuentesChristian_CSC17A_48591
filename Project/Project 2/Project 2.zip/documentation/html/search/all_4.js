var searchData=
[
  ['hiddeal_0',['hidDeal',['../class_deal_dek.html#a535aafc2d2f879ba59df549a7df45085',1,'DealDek']]]
];
