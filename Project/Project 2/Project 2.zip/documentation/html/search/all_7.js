var searchData=
[
  ['operator_2b_0',['operator+',['../class_dummy.html#aa4c9c34534988451a74b932df96abe5e',1,'Dummy::operator+()'],['../class_player.html#af14f8efb36e03c36a79d0f2590556484',1,'Player::operator+()']]],
  ['operator_2b_2b_1',['operator++',['../class_dummy.html#a90a52f55f82127cee585fc7c9b3e16c0',1,'Dummy::operator++()'],['../class_player.html#a93c354f284b2aaa9240ebaa3df811862',1,'Player::operator++()']]],
  ['operator_2d_2',['operator-',['../class_dummy.html#af03880e3f41f68c8bfd0e30ef1e3c296',1,'Dummy::operator-()'],['../class_player.html#ac6dbd388f3726560e8dc82205a64abbf',1,'Player::operator-()']]],
  ['operator_2d_2d_3',['operator--',['../class_dummy.html#a676d51851b5b6a4be2c94a3b42fb8072',1,'Dummy::operator--()'],['../class_player.html#af9d08208af3a561efb6c790c4e522e1f',1,'Player::operator--()']]]
];
