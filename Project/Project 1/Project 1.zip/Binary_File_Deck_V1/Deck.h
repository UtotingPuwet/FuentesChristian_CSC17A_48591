/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Deck.h
 * Author: UtotingPuwet
 *
 * Created on October 25, 2021, 4:13 PM
 */

#ifndef DECK_H
#define DECK_H
#include "Card.h"
struct Deck {
    Card *cards;
};


#endif /* DECK_H */

