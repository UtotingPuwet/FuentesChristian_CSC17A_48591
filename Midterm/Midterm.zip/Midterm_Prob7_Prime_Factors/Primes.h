/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Primes.h
 * Author: UtotingPuwet
 *
 * Created on October 22, 2021, 2:28 AM
 */

#ifndef PRIMES_H
#define PRIMES_H
#include "Prime.h"

struct Primes {
    unsigned char nPrimes = 0;
    Prime *prime;
};


#endif /* PRIMES_H */

