/* 
 * File:   main.cpp
 * Author: Christian Fuentes
 * Created on October 19, 2021 6:30PM
 * Purpose:  
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - No Global Variables

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    cout << "char maximum is 120 at factorial of 5.\n"
         << "unsigned char maximum is 208 at factorial of 6.\n"
         << "short maximum is 5040 at factorial of 7.\n"
         << "unsigned short maximum is 35200 at factorial of 9.\n"
         << "integer maximum is 479001600 at factorial of 12.\n"
         << "unsigned integer maximum is 2004189184 at factorial of 17.\n"
         << "long maximum is 2432902008176640000 at factorial of 20.\n"
         << "unsigned long is 17196083355034583040 at factorial of 22.\n"
         << "long maximum is 2432902008176640000 at factorial of 20.\n"
         << "unsigned long is 17196083355034583040 at factorial of 22.\n"
         << "float maximum is 479001600 at factorial of 12.\n"
         << "double maximum is 479001600 at factorial of 12.\n";
    //Exit stage right!
    return 0;
}