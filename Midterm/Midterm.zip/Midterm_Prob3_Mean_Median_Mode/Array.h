/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Array.h
 * Author: UtotingPuwet
 *
 * Created on October 20, 2021, 8:43 PM
 */

#ifndef ARRAY_H
#define ARRAY_H

struct Array{
    int size; //Size of the Array
    int *data;//Values contained in the array
};

#endif /* ARRAY_H */

