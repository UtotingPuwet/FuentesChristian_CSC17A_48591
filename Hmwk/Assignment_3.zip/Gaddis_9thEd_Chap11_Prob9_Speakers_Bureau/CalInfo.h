/*
 *File: Caller.h
 *Author: Christian Fuentes
 *Created on October 6th, 2021, 3:30 PM
 *Purpose: Caller structure
 */


#ifndef CalInfo_H
#define CalInfo_H

struct CalInfo {
    string name;
    long int phnNum;
    string topic;
    short feeReq;

};



#endif