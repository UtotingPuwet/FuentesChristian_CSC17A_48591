/* 
 * File:   DivInfo.h
 * Author: Christian Fuentes
 *
 * Created on October 12, 2021, 9:19 PM
 */

#ifndef DIVINFO_H
#define DIVINFO_H

struct DivInfo {

};


#endif /* DIVINFO_H */

