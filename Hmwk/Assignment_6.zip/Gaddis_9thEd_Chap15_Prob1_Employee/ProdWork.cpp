/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ProdWork.h
 * Author: UtotingPuwet
 *
 * Created on November 18, 2021, 12:51 AM
 */

#include "ProdWork.h"

ProdWork::ProdWork(int shift, float pay) {
    this->shift = shift;
    this->pay = pay;
}